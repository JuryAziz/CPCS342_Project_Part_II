package GraphFramework;

import LSRoutingApp.Router;

public class DijkstraAlg {

    Graph graph;

    private static final int NO_PARENT = -1;

    public DijkstraAlg(Graph graph) {
        this.graph = graph;
    }

    public void computeShortestPaths(int source) {

        long start = System.currentTimeMillis();

        int VertciesNo = graph.verticesNo;


        // array with shortest distances from source to vertex i
        int[] shortestDistances = new int[VertciesNo];


        // added[i] will only be true if the vertex i is in the shortest path tree 
        // or the distance from source to i is completed
        boolean[] added = new boolean[VertciesNo];

        // deafault values, distances as INF and added as False
        for (int vertexIndex = 0; vertexIndex < VertciesNo; vertexIndex++) {
            shortestDistances[vertexIndex] = Integer.MAX_VALUE;
            added[vertexIndex] = false;
        }

        // shortest distance from source to source is 0
        shortestDistances[source] = 0;

        // Parent array to store shortest path tree
        int[] parents = new int[VertciesNo];

        // source has no parent
        parents[source] = NO_PARENT;

        // Find shortest path for all vertices
        for (int i = 1; i < VertciesNo; i++) {

            // Pick the minimum distance vertex from the set of vertices not yet addedd. 
            // nearestVertex is equal to src in first iteration.
            int nearestVertex = 0;
            int shortestDistance = Integer.MAX_VALUE;
            
            for (int j = 0; j < VertciesNo; j++) {
                if (!added[j] && shortestDistances[j] < shortestDistance) {
                    nearestVertex = j;
                    shortestDistance = shortestDistances[j];
                }
            }

            // Mark the nearest vertex as added
            added[nearestVertex] = true;

            // Update distances to the adjacent vertices of the nearest vertex.
            // The distance will be updated by the sum of the shortest distance to the nearset vertex and the edge weight to the vertex j
            for (int j = 0; j < VertciesNo; j++) {
                Vertex srcVertex = graph.searchVertex(nearestVertex);
                int edgeDistance = srcVertex.getEdgeWeightWithVertex(j);
                if (edgeDistance > 0 && ((shortestDistance + edgeDistance) < shortestDistances[j])) {
                    parents[j] = nearestVertex;
                    shortestDistances[j] = shortestDistance + edgeDistance;
                }
            }
        }
        // calcualte time
        long end = System.currentTimeMillis();
        long time = end - start;
        System.out.println("Time: "+ time + " ms");
        
        // if the graph has over than 100 vertices do not print the paths
        if (graph.verticesNo < 100) {
            printSolution(source, shortestDistances, parents);
        }

    }

    private void printSolution(int startVertex, int[] distances, int[] parents) {

        int nVertices = distances.length;
        Router sourceVertex = (Router) graph.searchVertex(startVertex);
        System.out.println("The source router is " + sourceVertex.getRouterName());
        System.out
                .println("The paths from router " + sourceVertex.getRouterName() + " to the rest of the routers are:");

        for (int vertexIndex = 0; vertexIndex < nVertices; vertexIndex++) {
            // Skip the starting vertex
            if (vertexIndex != startVertex) {
                printShortestPath(parents[vertexIndex], parents);
                Router router = ((Router) graph.searchVertex(vertexIndex));
                System.out.println(router.displayInfo() + " route length: " + distances[vertexIndex]);

            }
        }
    }

    private void printShortestPath(int currentVertex, int[] parents) {

        if (currentVertex == NO_PARENT) {
            return;
        }
        printShortestPath(parents[currentVertex], parents);
        Router router = ((Router) graph.searchVertex(currentVertex));
        System.out.print(router.displayInfo() + " - ");
    }

}
