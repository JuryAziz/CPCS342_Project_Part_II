package GraphFramework;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

import LSRoutingApp.*;

public class Graph {


    public int verticesNo;
    public int edgeNo;
    public boolean isDigraph = false; // DIRECTED GRAPH
    public ArrayList<Vertex> verList = new ArrayList<Vertex>();

   
    public Graph() {

    }

    public Graph(int verticesNo, int edgeNo, boolean isDigraph) {
        this.verticesNo = verticesNo;
        this.edgeNo = edgeNo;
        this.isDigraph = isDigraph;
        verList = new ArrayList<Vertex>(verticesNo);
    }

    // ------------------------------------------- makeGraph ---------------------------------------------------
    /*
     * this function takes as parameters the number of vertices and the number
     * of edges.It is responsible for creating a graph object with the specified
     * parameters and randomly initializes the vertices’ labels, creating edges
     * that connects the created vertices randomly and assigning them random
     * weights.Make sure that the resulting graph is connected.
     *
     * @param verticesNo
     * @param edgeNo
     * @return
     */
    public void makeGraph(int verticesNo, int edgeNo) {
        // CREATE GRAPH OBJECT
        Random random = new Random();
        this.verticesNo = verticesNo;

        // ------------------------------------------- ## STEP 1 ## -------------------------------------------------------
        // CREATE VERTICES AND INITIALIZE THE LABELS
        for (int i = 0; i < verticesNo; i++) {
            Vertex ver = new Router(i);
            // INCREMENT NUM OF VERTICES IN GRAPH
            verList.add(ver);
        } // END FOR LOOP

        // ------------------------------------------- ## STEP 2 ## --------------------------------------------------------
        // CONNECT ALL VERTICES
        for (int i = 0; i < verticesNo - 1; i++) {

            // GENERATE RANDOM VALUE FOR WEIGHT
            int weight = random.nextInt(50) + 1;

            // ------------------------------------------- ASCENDING ORDER -----------------------------------------------------------
            if ((i + 1) > verticesNo - 1) {
                // REACHED LAST VERTEX, CONNECT WITH FIRST VERTEX
                addEdge(verList.get(i), verList.get(0), weight);

                // INCREMENT NUM OF EDGES IN GRAPH
                edgeNo++;
                continue;
            } // END IF

            // CREATE EDGE BETWEEN VERTICES
            addEdge(verList.get(i), verList.get(i + 1), weight);

            // INCREMENT NUM OF EDGES IN GRAPH
            edgeNo++;

            if (!isDigraph) {

                // CREATE EDGE BETWEEN VERTICES
                addEdge(verList.get(i + 1), verList.get(i), weight);

                // INCREMENT NUM OF EDGES IN GRAPH
                edgeNo++;
            } // END IF
        } // END FOR LOOP

        // ------------------------------------------- ## STEP 3 ## --------------------------------------------------------
        // CREATE REMAINING EDGES RANDOMLY BETWEEN VERTICES
        // CALCULATE REMAINING EDGES
        int remEdge = edgeNo - (verticesNo - 1);

        // CONNECT VERTICES RANDOMLY
        for (int i = 0; i < remEdge; i++) {

            // GENERATE RANDOM VALUE FOR SRC AND DEST VERTICES
            int srcVert = random.nextInt(verticesNo);
            int destVert = random.nextInt(verticesNo);

            // CHECK TO AVOID FOR DUPLICATE EDGES
            if (destVert == srcVert || CheckEdge(srcVert, destVert)) { 
                i--;
                continue;
            } // END IF

            // GENERATE RANDOM VALUE FOR WEIGHT
            int weight = random.nextInt(50) + 1;
            // CREATE EDGE BETWEEN VERTICES
            addEdge(verList.get(srcVert), verList.get(destVert), weight);

            // INCREMENT NUM OF EDGES IN GRAPH
            edgeNo++;

            // IF GRAPH IS UNDIRECTED
            if (!isDigraph) {

                // CREATE EDGE BETWEEN VERTICES
                addEdge(verList.get(destVert), verList.get(srcVert), weight);

                // INCREMENT NUM OF EDGES IN GRAPH
                edgeNo++;
            } // END IF
        } // END FOR LOOP

    }

    public void readGraphFromFile(File filename) {

        try (Scanner in = new Scanner(filename)) {

            in.next();
            isDigraph = (in.nextInt() == 1);

            verticesNo = in.nextInt();
            edgeNo = in.nextInt();

            for (int i = 0; i < edgeNo; i++) {

                char srcName = in.next().charAt(0);
                char desName = in.next().charAt(0);
                int edgeWeight = in.nextInt();

                // search for src
                Vertex src = Graph.this.searchVertex(srcName);
                // search for des
                Vertex des = Graph.this.searchVertex(desName);

                // create house object for the new house
                if (src == null) {
                    // src ver
                    src = new Router(((int)(srcName - 65)), srcName);
                    verList.add(src);
                }

                if (des == null) {
                    // dest ver
                    des = new Router(((int)(desName - 65)), desName);
                    verList.add(des);
                }

                addEdge(src, des, edgeWeight);
            }

        } catch (FileNotFoundException e) {
            System.out.println("File Not Found");
        }

    }

    public void addEdge(Vertex srcVer, Vertex destVer, int weight) {
        Edge edge = new Path(srcVer, destVer, weight);
        srcVer.adjList.add(edge);
        Edge.totalEdges.add(edge);
    }

    public Vertex searchVertex(char name) {

        for (int i = 0; i < verList.size(); i++) {
            if (((Router) verList.get(i)).getRouterName() == name) {
                return verList.get(i);
            }
        }

        return null;
    }

    public Vertex searchVertex(int label) {

        for (int i = 0; i < verList.size(); i++) {
            if (verList.get(i).label == label) {
                return verList.get(i);
            }
        }

        return null;
    }

    // ------------------------------------------- CheckEdge ---------------------------------------------------
    public boolean CheckEdge(int src, int dest) {
        // SEARCH IF THERE IS EDGE FROM SRC TO DEST
        ArrayList<Edge> totalEdges = Edge.totalEdges;
        for (int i = 0; i < totalEdges.size(); i++) {
            Edge temp = totalEdges.get(i);
            if (temp.srcVer.label == src && temp.destVer.label == dest) {
                return true;
            } // END IF
        } // END FOR LOOP I
        // IF THERE IN NO MATCH RETURN FALSE
        return false;

    }// END METHOD

    // print graph
    public void printGraph() {
        // ARRAY LIST
        for (int i = 0; i < verList.size(); i++) {
            // Linked list
            for (int j = 0; j < verList.get(i).adjList.size(); j++) {

                Edge temp = verList.get(i).adjList.get(j);
                System.out.print(temp.srcVer.displayInfo() + "    -   ");
                System.out.print(temp.destVer.displayInfo() + "    -   ");
                System.out.print(temp.displayInfo() + "\n");
            } // END FOR LOOP J
        } // END FOR LOOP I
    }// END METHOD

}// END CLASS
