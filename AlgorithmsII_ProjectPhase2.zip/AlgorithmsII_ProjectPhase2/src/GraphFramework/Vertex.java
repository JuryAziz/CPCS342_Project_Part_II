package GraphFramework;

import java.util.*;

public class Vertex implements Comparable<Vertex> {

    // DATA FIELD
    public int label;
    public LinkedList<Edge> adjList = new LinkedList<>(); 
    public int parent = -1; 
    public int rank = 0;
    public int key = Integer.MAX_VALUE;

    public Vertex() {

    }

    public Vertex(int label) {
        this.label = label;
    }

    public String displayInfo() {
        return "Vertex: " + label;
    }

    @Override
    public int compareTo(Vertex o) {
        return (this.key - o.key);
    }

    // SEARCH FOR THE EDGE BETWEEN THIS VERTEX AND vertexIndex 
    // RETURN 0 IF NOT FOUND
    public int getEdgeWeightWithVertex(int index) {
        for (Edge edge : adjList) {
            if (edge.destVer.label == index) {
                return edge.weight;
            }
        }
        return 0;
    }

}
