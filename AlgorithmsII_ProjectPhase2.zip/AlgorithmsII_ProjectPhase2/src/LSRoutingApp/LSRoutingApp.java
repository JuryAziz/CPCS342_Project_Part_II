package LSRoutingApp;

/*
 * CPCS324 Project Part 2
 * Fall 2022 
 * Juri Alsubhi, Shahad Hanbuli, Bashayer alsulami 
 */

import GraphFramework.*;

import java.io.*;
import java.util.*;

public class LSRoutingApp {

    static Graph network;

    public static void main(String[] args) throws FileNotFoundException {

        Scanner in = new Scanner(System.in);

        int verticesNO = 0;
        int edgesNO = 0;
        boolean isDigraph = true;

        System.out.println("1- Requirement 1 Using Read_from_File Funcation. \n"
                + "2- Requirement 2 Using Make_Graph Funcation.\n");

        System.out.print("Select Requirement Option: ");

        int choice = in.nextInt();

        while (choice != 1 && choice != 2) {
            System.out.println("Wrong Selection. ");
            System.out.print("Select Requirement Option: ");
            choice = in.nextInt();
        }

        if (choice == 1) {
            System.out.println("\n Requirement 1 Using Read From File function \n");

            File file = new File("graph.txt");
            network = new Graph();
            network.readGraphFromFile(file);

        }

        if (choice == 2) {
            System.out.println("\n_______Requirement 2 Using Make Graph function_______\n");


            System.out.println("\n 1-  n=2000 , m=10000");
            System.out.println(" 2-  n=3000 , m=15000");
            System.out.println(" 3-  n=4000 , m=20000");
            System.out.println(" 4-  n=5000 , m=25000");
            System.out.println(" 5-  n=6000 , m=30000");

            System.out.print("\nSelect your Test Option: ");
            choice = in.nextInt();

            while (choice > 5 || choice < 1) {
                System.out.println("Option not found.");
                System.out.print("Select your Test Option: ");
                choice = in.nextInt();
            }

            switch (choice) {
                case 1:
                    verticesNO = 2000;
                    edgesNO = 10000;
                    break;

                case 2:
                    verticesNO = 3000;
                    edgesNO = 15000;

                    break;
                case 3:
                    verticesNO = 4000;
                    edgesNO = 20000;
                    break;
                case 4:
                    verticesNO = 5000;
                    edgesNO = 25000;

                    break;
                case 5:
                    verticesNO = 6000;
                    edgesNO = 30000;
                    break;
            }

            network = new Graph(verticesNO, edgesNO, isDigraph);
            network.makeGraph(verticesNO, edgesNO);

        }
        DijkstraAlg dijkstraAlg = new DijkstraAlg(network);
        dijkstraAlg.computeShortestPaths(0);
        in.close();

    }

}
