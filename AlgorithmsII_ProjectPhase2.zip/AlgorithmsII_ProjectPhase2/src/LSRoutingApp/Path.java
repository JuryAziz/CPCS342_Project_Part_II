package LSRoutingApp;
import GraphFramework.*;

public class Path extends Edge {
    
    private int pathSize;
    static int count = 1;


    public Path(Vertex srcVer, Vertex destVer, int weight) {
        super(srcVer, destVer, weight);
        this.pathSize = weight;

    }
     
   public int GetPathSize(){
    return pathSize;
   }

    @Override
    public String displayInfo(){
        return "Length : " + pathSize;
   }

}
