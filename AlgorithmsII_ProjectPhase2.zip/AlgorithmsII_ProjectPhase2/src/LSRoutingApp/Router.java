package LSRoutingApp;

import GraphFramework.*;

public class Router extends Vertex{
    
  private char RouterName;

    // CONSTRUCTOR
    public Router() {

    }
    
    public Router(int label) {
      super(label);
    }
    
    public Router(int label, char RouterName) {
      super(label);
      this.RouterName = RouterName;
    }
   
    @Override
    public String displayInfo(){
      return "Rt. " + this.RouterName;
    }

    public char getRouterName(){
      return RouterName;
    }

}
